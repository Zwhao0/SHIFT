#!/usr/bin/env python3
"""Validate collected v1 evidence, then write concise Chinese release notes."""
import argparse, json
from pathlib import Path

MODES = ("cold", "cpu", "gpu")

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def need(ok, message):
    if not ok: raise ValueError(message)

def fmt(value, digits=3):
    return "n/a" if not isinstance(value, (int, float)) else f"{value:.{digits}f}"

def per_step(raw):
    out = []
    for step, ranks in sorted(raw.get("byrank", {}).items(), key=lambda x: int(x[0])):
        pairs = [v for v in ranks.values() if isinstance(v, dict)]
        categories = {}
        for category in ("gradients", "model", "optimizer", "scheduler"):
            values = [p.get("by_category", {}).get(category, {}) for p in pairs]
            metrics = [v.get("metrics", {}) for v in values]
            categories[category] = {
                "pass_count": sum(v.get("pass") is True for v in values),
                "max_abs": max((m["max_abs"] for m in metrics if isinstance(m.get("max_abs"), (int, float))), default=None),
                "max_relative_l2": max((m["relative_l2"] for m in metrics if isinstance(m.get("relative_l2"), (int, float))), default=None),
            }
        out.append({"step": int(step), "role_pairs": len(pairs),
                    "failed_pairs": [f"step{step}/rank{r}" for r, p in ranks.items() if not isinstance(p, dict) or p.get("pass") is not True],
                    "by_category": categories})
    return out

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", type=Path, default=Path(".")); root = ap.parse_args().root.resolve()
    v1 = root / "results/v1"
    short, long = read(v1/"short_verify.json"), read(v1/"long_verify.json")
    backups, bench, traj = (read(v1/n) for n in ("backup_summary.json", "benchmark_abba.json", "trajectory_summary.json"))
    audits = {m: read(v1/f"v1_backup_audit_{m}_01_verify.json") for m in MODES}
    raw_comp = read(v1/"trajectory_comparison.json")

    need(short.get("pass") is True and short.get("fault_window", {}).get("completed_faults") == 10, "short rotation evidence failed")
    fw = long.get("fault_window", {})
    need(long.get("pass") is True and fw.get("completed_faults") == 60 and fw.get("completed_seconds", 0) >= 3600
         and fw.get("schedule_late_events") == 0, "long rotation evidence failed")
    need(long.get("coverage", {}).get("physical_nodes") == ["node0", "node1", "node3"]
         and long.get("coverage", {}).get("logical_rids") == [0, 1], "long physical-node/rid coverage incomplete")
    for mode, report in audits.items():
        need(report.get("pass") is True and report.get("fault_window", {}).get("completed_faults") == 1,
             f"{mode} full-state audit failed")
    for mode in MODES:
        row = backups.get("modes", {}).get(mode, {})
        need(row.get("complete") is True and row.get("trial_count") == 3 and len(row.get("trials", [])) == 3,
             f"{mode} timing trials incomplete")
        for metric in ("preparation_seconds", "fault_to_joint_seconds", "request_to_ready_seconds",
                       "recovery_request_to_state_loaded_seconds", "healthy_max_adjacent_gap_seconds"):
            need(row.get("metrics", {}).get(metric, {}).get("count") == 3, f"{mode} missing {metric} trials")
    need(bench.get("abba_complete") is True and bench.get("combined_comparison_complete") is True, "ABBA benchmark incomplete")
    checks = traj.get("checks", {})
    for key in ("input_read", "same_initial_state", "same_batch_plans", "participants_and_global_batch"):
        need(checks.get(key, {}).get("pass") is True, f"trajectory check failed: {key}")
    initial = traj.get("initial_state", {})
    need(initial.get("expected_role_count") == 16 and initial.get("roles_present") == {"flat": 16, "shift": 16}
         and len(initial.get("hash_fields", [])) == 7, "trajectory must compare all 16 initial seven-hash states")
    need(traj.get("step_coverage", {}).get("numerical_commit_steps") == [2, 3, 4]
         and traj.get("step_coverage", {}).get("pre_update_batch_and_routing_steps") == [1, 2, 3], "trajectory step coverage mismatch")
    need(raw_comp.get("checks", {}).get("files_present", {}).get("pass") is True
         and raw_comp.get("checks", {}).get("loads_succeeded", {}).get("pass") is True, "trajectory reference snapshots unavailable")
    need(raw_comp.get("steps") == [2, 3, 4] and raw_comp.get("ranks") == list(range(8))
         and isinstance(raw_comp.get("byrank"), dict), "trajectory comparator coverage mismatch")
    num = traj.get("numerical_comparison")
    need(isinstance(num, dict) and isinstance(num.get("pass"), bool), "trajectory numerical comparison missing")
    step_metrics = per_step(raw_comp)
    need(len(step_metrics) == 3 and all(row["role_pairs"] == 8 for row in step_metrics), "trajectory comparison must cover 24 role-step pairs")

    faults = long.get("faults", [])
    rank_restores = sum(f.get("restored_rank_count", 0) for f in faults)
    first_joint_roles = sum(f.get("first_joint_hash_roles", 0) for f in faults)
    rpo0 = sum(f.get("restored_step", -1) >= f.get("highest_joint_step_before_fault", 0) for f in faults)
    lighthouse_alive = sum(f.get("lighthouse_alive") is True for f in faults)
    healthy_pid_stable = sum(f.get("healthy_pids_unchanged") is True for f in faults)
    timing = long["timing_percentiles"]
    modes = backups["modes"]
    fastest = min(MODES, key=lambda m: modes[m]["metrics"]["fault_to_joint_seconds"].get("median", float("inf")))
    benchmark = bench.get("combined", {})
    route = traj.get("routing", {})
    summary = {
        "phase_complete": True, "github_publication": "pending",
        "short_rotation": {"session": short.get("session"), "faults": 10, "pass": short["pass"]},
        "long_rotation": {"session": long.get("session"), "pass": long["pass"], "fault_window": fw,
            "restored_rank_hashes": rank_restores, "first_joint_hash_role_pairs": first_joint_roles,
            "rpo0_faults": rpo0, "lighthouse_alive_faults": lighthouse_alive,
            "healthy_pid_stable_faults": healthy_pid_stable,
            "steady_joint_steps": len(long.get("audited_joint_steps", [])),
            "steady_joint_role_pairs": long.get("audited_joint_role_pairs"), "timing_percentiles": timing},
        "full_state_audits": {m: {"pass": audits[m]["pass"], "faults": 1} for m in MODES},
        "backup_timing": backups, "fastest_median_fault_to_joint_mode": fastest,
        "benchmark_abba": {"order": bench.get("abba_order"), "mean_step_seconds_change_percent": benchmark.get("mean_step_seconds_percent_change_shift_vs_flat"),
            "throughput_change_percent": benchmark.get("throughput_percent_change_shift_vs_flat"), "flat": benchmark.get("flat"), "shift": benchmark.get("shift")},
        "trajectory": {"checks": checks, "step_coverage": traj.get("step_coverage"), "initial_state": initial,
            "batch_plans": traj.get("batch_plans"), "participants_and_global_batch": traj.get("participants_and_global_batch"),
            "routing": route, "numerical_comparison": traj.get("numerical_comparison"),
            "numerical_by_step": step_metrics, "interpretation": traj.get("interpretation")},
        "limitations": ["进程树SIGKILL故障，控制器/Lighthouse存活；未验证主机断电。", "副本失效时有效batch从8变4；数值诊断固定batch8。",
            "每节点一个8-GPU副本；GPU热备需要额外8-GPU容量。", "未运行完整同负载TorchTitan对照。", "运行依赖现有模型、FLASH1022/旧Core及runtime manifest。"],
        "evidence_scope": "results/v1精选JSON和压缩原始日志；不含凭据、模型.pt或runtime上传。",
    }
    (v1/"summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True)+"\n", encoding="utf-8")

    audit = ", ".join(f"{m} 1/1" for m in MODES)
    bm = summary["benchmark_abba"]; num = summary["trajectory"]["numerical_comparison"]
    route_first = route.get("first_differences", [])
    route_note = f"首个路由差异：{route_first[0]}" if route_first else f"路由差异：{route.get('different_count', 'n/a')}；首次分歧step={route.get('first_divergent_pre_update_step')}"
    prep_cmds = """```bash
python3 -m shift_full.deploy --include-node3
python3 -m shift_full.rotation --session UNIQUE_LONG --config configs/shift_rotation_verify.json --seconds 4800 --faults 60 --interval 60 --duration 3600 --seed 20261102
python3 -m shift_full.rotation --session UNIQUE_GPU_HOT_AUDIT --config configs/shift_rotation_audit512.json --seconds 900 --faults 1 --backup-mode gpu --seed 20261102
python3 scripts/unpack_v1_evidence.py --evidence results/v1 --output tmp/v1-evidence
python3 -m shift_full.verify_rotation tmp/v1-evidence/v1_rotation_long_20261102_01 --expected-faults 60 --minimum-duration 3600
```"""
    docs = {
        "README.md": f"# SHIFT v1\n\n三机进程故障恢复实验已完成。长测60次/3600秒通过，状态恢复、首个共同提交与RPO0均经离线原始日志核验。GitHub发布待完成，当前文档不表示已上传。\n\n- 数值三步对照：`{str(num.get('pass')).lower()}`；按原容差报告，未放宽。\n- ABBA步时变化：{fmt(bm.get('mean_step_seconds_change_percent'),2)}%；备份建议：{fastest}（GPU热备需预留8张GPU）。\n- 详细证据：`RESULTS.md`、`results/v1/summary.json`。\n\n{prep_cmds}\n",
        "RESULTS.md": f"# v1 实验结果\n\n## 故障恢复\n\n- 短测：10/10通过。长测：{fw['completed_faults']}/60，{fw['completed_seconds']:.3f}秒，schedule_late={fw['schedule_late_events']}。\n- 恢复全状态：{rank_restores}/480 rank-hash；首个共同提交：{first_joint_roles}/480 rank-hash；RPO0：{rpo0}/60。Lighthouse存活{lighthouse_alive}/60，健康PID不变{healthy_pid_stable}/60。稳态审计{len(long.get('audited_joint_steps',[]))}步、{long.get('audited_joint_role_pairs')}角色-步。\n- 长测审计开启、seq16：完整故障→共同步p50/p95 {fmt(timing['fault_to_joint_seconds']['median'])}/{fmt(timing['fault_to_joint_seconds']['p95'])}秒；这是带审计结果。seq512关闭审计的三轮计时见下表，口径分开。\n- 全状态模式审计：{audit}均通过。\n\n## 备份计时（seq512，关闭审计）\n\n| 模式 | 准备p50 | 故障→共同步p50 | 请求→就绪p50 | 恢复请求→加载p50 | 故障期健康max间隔p50 | 准备期健康max间隔p50 |\n|---|---:|---:|---:|---:|---:|---:|\n" + "\n".join(f"| {m} | {fmt(modes[m]['metrics']['preparation_seconds'].get('median'))} | {fmt(modes[m]['metrics']['fault_to_joint_seconds'].get('median'))} | {fmt(modes[m]['metrics']['request_to_ready_seconds'].get('median'))} | {fmt(modes[m]['metrics']['recovery_request_to_state_loaded_seconds'].get('median'))} | {fmt(modes[m]['metrics']['healthy_max_adjacent_gap_seconds'].get('median'))} | {fmt(modes[m]['metrics']['healthy_max_adjacent_gap_preparation_seconds'].get('median'))} |" for m in MODES) + f"\n\n最快实测中位故障→共同步为 `{fastest}`；GPU热备需要额外预留整组8-GPU副本。保留cold作为基线。GPU/RSS/CUDA分项见 `results/v1/summary.json` 的backup_timing。预备期跨副本通信为结构性零（Manager在ACTIVATE前未构造）；这不是带宽测量结论。\n\nABBA flat→SHIFT→SHIFT→flat；步时变化 {fmt(bm.get('mean_step_seconds_change_percent'),2)}%，吞吐变化 {fmt(bm.get('throughput_change_percent'),2)}%。\n\n## 数值轨迹\n\n以相同step1精确状态起点，比较commit step2/3/4；batch与路由计划覆盖pre-update step1/2/3。16个角色的7项起始哈希、batch、输入和participants/global_batch检查通过。原比较容差保留；数值比较通过=`{num.get('pass')}`，failed pairs=`{num.get('failed_pairs')}`。逐step/类别最大绝对误差、relative-L2见 `results/v1/summary.json`。\n\n{route_note}。路由边界margin见汇总JSON。观测不证明根因；FP32 reduction/addition顺序差异只是可能解释。\n\n## 范围\n\n故障是训练进程树SIGKILL，Lighthouse/控制面存活；动态batch由8变4，固定batch8只用于数值轨迹。每节点一个8-GPU副本。未运行完整同负载TorchTitan对照，未验证主机掉电。精选公开证据不含凭据、模型.pt或runtime上传。\n",
        "OPTIMIZATION_NOTES.md": f"# v1 优化与证据\n\n推荐保持cold恢复作为基线；本轮审计通过的三种模式为 {audit}。按三轮关闭审计的故障→共同步中位数，最快为 `{fastest}`。若采用GPU热备，须保留额外8-GPU容量；资源明细在 `results/v1/backup_summary.json`。\n\nABBA测得SHIFT步时变化 {fmt(bm.get('mean_step_seconds_change_percent'),2)}%，吞吐变化 {fmt(bm.get('throughput_change_percent'),2)}%。长测seq16且开启状态审计，RTO p50/p95 {fmt(timing['fault_to_joint_seconds']['median'])}/{fmt(timing['fault_to_joint_seconds']['p95'])}秒；seq512计时关闭审计，不能混作同口径。\n\n三更新FP32对照通过原容差=`{num.get('pass')}`；failed pairs=`{num.get('failed_pairs')}`。batch/输入/起始7哈希检查通过。{route_note}。路由margin与逐step范数在汇总JSON。证据不支持确定根因；FP32加法/reduction次序是可能性，不是结论。\n",
        "CURRENT_PLAN.md": "# 当前状态\n\n- v1实验与证据核验已完成；本阶段无待运行实验。\n- `results/v1/summary.json` 汇总长测、备份模式、ABBA和FP32轨迹。数值比较即使失败也按原容差明确保留。\n- GitHub `Zwhao0/SHIFT` 上传仍待执行；本文档不宣称已发布。发布前检查manifest、凭据扫描和`.pt`排除。\n- 限制：仅进程树SIGKILL、控制服务存活；不代表主机掉电或完整TorchTitan等价。\n",
        "handoff.md": f"# SHIFT v1 交接\n\n实验阶段已完成，证据汇总于 `results/v1/summary.json`。长测60/60、3600秒；状态恢复hash {rank_restores}/480，首个joint hash {first_joint_roles}/480，RPO0 {rpo0}/60。seq16审计RTO p50/p95 {fmt(timing['fault_to_joint_seconds']['median'])}/{fmt(timing['fault_to_joint_seconds']['p95'])}秒。\n\n数值step2–4比较原容差结果：`{num.get('pass')}`，failed pairs `{num.get('failed_pairs')}`；不得放宽容差或称完全等价。发布状态：GitHub待上传。原始证据可用 `scripts/unpack_v1_evidence.py` 解包，再运行`shift_full.verify_rotation`。\n\n边界与复现命令见 `README.md`、`RESULTS.md`。不上传凭据、模型.pt或runtime。\n",
    }
    for name, content in docs.items(): (root/name).write_text(content, encoding="utf-8")
    print(json.dumps({"phase_complete": True, "summary": str(v1/"summary.json"), "github_publication": "pending"}, ensure_ascii=False))

if __name__ == "__main__": main()
